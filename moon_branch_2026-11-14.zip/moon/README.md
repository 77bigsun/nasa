# Moon 分析：特徵、公式與結果（2026-11-14 20:10 更新）

負責：月球端（月球南極基地 vs 地球類比地點）。火星不在這個資料夾。
狀態：**初步結果**。錨點與權重是提案，交件前要隊友確認。

## 1. 共通公式

每個特徵算出相似度 s（0 到 1，越高越像月球），再依 11/11 模型合成：

    Score = 100 · Σ(w · c · s) / Σ(w · c)

- w：權重（I × U 正規化）
- c：資料適配度，直接量測 1.0、代理資料 0.6、文獻 0.3、無資料 0

測試權重（11/13 ROC）：M5 0.408、M3 0.242、M4 0.158、M2 0.103、M6 0.061、M1 0.028

### 函數型式

| 名稱 | 數學式 | 用途 |
|---|---|---|
| D 型（單向線性） | s = clip((x − b) / (t − b), 0, 1) | 越極端越像（越冷、越暗）。b = 0 分錨點，t = 1 分錨點 |
| D′ 型（對數） | s = clip((ln x − ln b) / (ln t − ln b), 0, 1) | 跨數量級的量（乾燥度） |
| 高斯型 | s = exp(−(x − μ)² / (2σ²)) | 剛好等於月球值最好，μ = 月球值 |
| 對數高斯 | s = exp(−[ln(x/μ)]² / (2σ²)) | 比例型的量（起伏） |
| 直方圖交集 | s = Σ min(p_E,i , p_M,i) | 分布比較（坡度、粒徑） |
| 檢核表 | s = Σ 權重 × 是否符合 | 冰與凍土 |

clip(u, 0, 1) = min(max(u, 0), 1)

## 2. 特徵、公式與狀態

| 測試 | 特徵 | 公式 | 參數 | 狀態 | 結果檔 |
|---|---|---|---|---|---|
| M1 | 細尺度地形 | — | 需要 1–5 m 地球 DEM，且跟 M4 重複 | 不評估 | — |
| M2 | 正午太陽高度角 | D 型，x = 90 − abs(緯度) | b = 90°、t = 5° | 已算 | new_features_results.csv（另見下方） |
| M2 | 低角度光照比例 | D 型，x = 白天時段中太陽高度 < 10° 的比例 | b = 0、t = 1 | 已算 | new_features_results.csv |
| M3 | 最長連續黑暗 | D 型，x = 一年中最長一段夜晚（小時） | b = 12 h、t = 120 h | 已算 | new_features_results.csv |
| M3 | 年最低溫 | D 型 | b = 0 °C、t = −89 °C | 已算 | new_features_results.csv |
| M3 | 日夜溫差 | D 型 | b = 10 °C、t = 40 °C | 已算（氣溫） | new_features_results.csv |
| M4 | 坡度分布 | 直方圖交集，分箱 0–5、5–10、10–15、15–20、20–30、>30° | 月球 LOLA Site01（Connecting Ridge）30 m | 已算 | M4_slope_results.csv |
| M4 | 起伏（16 km 範圍高低差） | 對數高斯 | μ = 2477 m、σ = ln 2 | 已算 | new_features_results.csv |
| M5 | 粒徑 S_G | 直方圖交集（6 箱），缺值用端點上下限 | Apollo 16 平均粒徑分布 | 已算（範圍） | M5_site_ranges.csv |
| M5 | 熱紅外 S_T | 高斯，Christiansen Feature 位置 | 月球 CF = 8.128 µm | 未評估（ASTER 解析不出 CF） | — |
| M5 | 可見光到短波紅外 S_V | 去連續譜加權距離 exp(−D²/2) | 月球參考待換成新鮮高地物質 | 未評估 | — |
| M5 | 總分 | S_M5 = 100(0.60 S_G + 0.20 S_T + 0.20 S_V)，缺項報範圍 [K, K + 100(1 − C)] | — | 範圍 | M5_site_ranges.csv |
| M6 | 年均溫 | D 型 | b = 15 °C、t = −55 °C | 已算 | new_features_results.csv |
| M6 | 年最高溫 | D 型 | b = 40 °C、t = −20 °C | 已算 | new_features_results.csv |
| M6 | 冰與凍土 | 檢核表：永凍土 0.4 + 地下冰 0.3 + 冷阱冰 0.3 | 需逐點查文獻 | 未做 | — |

M2 正午太陽高度角的分數：Craters of the Moon 0.511、Lunar Crater 0.452、Cuprite 0.442、死亡谷 0.435、Black Point 0.420、加州農田 0.388、白沙 0.386、阿爾及利亞 0.359、阿他加馬 0.283、烏尤尼 0.238、Mauna Kea 0.233、Kaʻū 0.228。

## 3. 地點（12 個）

| ID | 類別 | 緯度 | 經度 |
|---|---|---|---|
| ATACAMA_YUNGAY | known | −24.09 | −69.92 |
| DEATHVALLEY_UBEHEBE | known | 37.010 | −117.450 |
| HAWAII_MAUNAKEA | known | 19.82 | −155.47 |
| HAWAII_KAU_DESERT | known | 19.35 | −155.36 |
| AZ_BLACK_POINT_LAVA | known | 35.67 | −111.47 |
| NV_LUNAR_CRATER | known | 38.38 | −116.07 |
| ID_CRATERS_OF_MOON | known | 43.42 | −113.52 |
| BOLIVIA_UYUNI_SALT | control | −20.20 | −67.60 |
| NM_WHITE_SANDS | control | 32.78 | −106.30 |
| NV_CUPRITE_CLAY | control | 37.54 | −117.18 |
| ALGERIA_GRAND_ERG | control | 30.50 | 7.50 |
| CA_IMPERIAL_CROPS | control | 33.00 | −115.50 |

## 4. 已知限制

- 溫度四項用 ERA5（Open-Meteo archive API，2014–2023）**2 m 氣溫**，不是地表溫度；地表日夜溫差會大很多。解析度約 10 km。
- 光照、黑暗只用緯度和天文公式算，沒有地形遮蔽。
- 12 個點都在中低緯度，所以光照、黑暗兩項分數全部偏低；要高分得選北緯 66.5° 以上。
- 月球南極的溫度與光照，地球任何地點都達不到，D 型的 t 取地球上最接近月球的極端值。
- M5 的 S_V 用目前的南極 M3 光譜會讓對照組排名偏高，方法暫停，待換參考光譜。

## 5. 檔案

| 路徑 | 內容 |
|---|---|
| results/new_features_results.csv | 起伏、低角度光照、最長黑暗、年均溫、年最高溫、年最低溫、日夜溫差（原始值與 s） |
| results/M4_slope_results.csv | 坡度直方圖、S_slope、16 km 起伏 |
| results/M5_site_ranges.csv | M5 粒徑上下限與總分範圍 |
| moon_reference/ | 月球參考值（Diviner CF、Apollo 16 粒徑、M3 南極光譜） |
| earth_data/ | EMIT 反射光譜、PlanetGSD 地球粒徑 |
| code/ | m5_model.py（M5 v1.0）、lunar_analog_score.py（總分框架）、new_features.py、temps.py、earth_gsd.py |

## 6. 資料來源

Chandrayaan-1 M3 L2（PDS）、Lucey et al. 2021 Diviner CF（Zenodo 4558235）、LRO LOLA 5 m PGDA Site01、AWS Terrain Tiles（SRTM）、PlanetGSD 1.0（Figshare 10.6084/m9.figshare.32362083，CC BY 4.0）、EMIT L2A RFL（NASA AppEEARS）、ERA5 via Open-Meteo。

程式由 Claude（Anthropic）協助產生，交件時記得在 AI 使用欄位揭露。
